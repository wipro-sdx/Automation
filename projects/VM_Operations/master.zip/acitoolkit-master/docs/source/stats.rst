Statistics
==========
This documents gives an overview of the statistics.

.. toctree::
   :maxdepth: 2

   statsbody
   statsdetail
