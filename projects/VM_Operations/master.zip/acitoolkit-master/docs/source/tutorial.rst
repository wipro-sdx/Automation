Tutorial
========
This document is meant to give a tutorial-like overview of the
acitoolkit package.

.. toctree::
   :maxdepth: 2

   tutorialsetup
   tutorialpackages
   tutorialsimpleconfig
   subscriptions
